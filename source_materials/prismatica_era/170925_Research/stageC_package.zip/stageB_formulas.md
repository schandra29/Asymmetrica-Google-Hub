Model 0 :: if_mod12_eq_10 | if_mod30_eq_2 | if_mod3_eq_2 | if_mod5_eq_2 | if_v2_ge_5
steps_hat = 7.684647 * log2n + -6.260638 * v2 + 0.484293 * if_mod12_eq_10 + 0.484293 * if_mod12_eq_10*v2 + 0.707801 * if_mod30_eq_2*v2 + 0.039375 * if_mod3_eq_2*v2 + -0.283208 * if_mod5_eq_2 + -0.537373 * if_mod5_eq_2*v2 + 0.837384 * if_v2_ge_5*log2n + -1.905392 * if_v2_ge_5*v2
---
Model 1 :: if_mod12_eq_10 | if_mod30_eq_2 | if_mod5_eq_2 | if_v2_ge_2 | if_v2_ge_6
steps_hat = -1.457755 * bias + 7.572251 * log2n + -3.55346 * v2 + 0.55833 * if_mod12_eq_10 + 0.55833 * if_mod12_eq_10*v2 + 0.761664 * if_mod30_eq_2*v2 + -0.256169 * if_mod5_eq_2 + -0.564435 * if_mod5_eq_2*v2 + -0.81072 * if_v2_ge_2 + 0.34879 * if_v2_ge_2*log2n + -2.906425 * if_v2_ge_2*v2 + 1.397104 * if_v2_ge_6*log2n + -2.646071 * if_v2_ge_6*v2
---
Model 2 :: if_mod12_eq_10 | if_mod3_eq_2 | if_mod5_eq_2 | if_v2_ge_3 | if_v2_ge_4
steps_hat = -0.662631 * bias + 7.695733 * log2n + -5.889073 * v2 + 0.566551 * if_mod12_eq_10 + 0.566551 * if_mod12_eq_10*v2 + 0.184883 * if_mod3_eq_2*v2 + -0.87703 * if_mod5_eq_2 + -1.683937 * if_v2_ge_3 + 0.256541 * if_v2_ge_3*v2 + -2.357029 * if_v2_ge_4 + 0.736429 * if_v2_ge_4*log2n + -1.762736 * if_v2_ge_4*v2
---
Model 3 :: if_mod30_eq_2 | if_mod5_eq_2 | if_v2_ge_3 | if_v2_ge_4 | if_v2_ge_8
steps_hat = -0.268479 * bias + 7.714356 * log2n + -6.139968 * v2 + -0.298088 * if_mod30_eq_2*log2n + 1.942512 * if_mod30_eq_2*v2 + 1.005564 * if_mod5_eq_2 + -0.97158 * if_mod5_eq_2*v2 + -3.939094 * if_v2_ge_3 + 1.134221 * if_v2_ge_3*v2 + -4.762302 * if_v2_ge_4 + 0.711145 * if_v2_ge_4*log2n + -1.335403 * if_v2_ge_4*v2 + 1.004376 * if_v2_ge_8*log2n + -2.166043 * if_v2_ge_8*v2
---
Model 4 :: if_mod3_eq_2 | if_mod5_eq_2 | if_v2_ge_3 | if_v2_ge_6
steps_hat = 7.70893 * log2n + -6.251777 * v2 + -0.883536 * if_mod5_eq_2 + -0.504094 * if_v2_ge_3 + -0.014038 * if_v2_ge_3*v2 + 1.491439 * if_v2_ge_6*log2n + -2.922774 * if_v2_ge_6*v2
---
Model 5 :: if_mod12_eq_10 | if_mod30_eq_2 | if_mod5_eq_2 | if_v2_ge_5 | if_v2_ge_7
steps_hat = 7.684886 * log2n + -6.248554 * v2 + 0.477794 * if_mod12_eq_10 + 0.477794 * if_mod12_eq_10*v2 + 0.764563 * if_mod30_eq_2*v2 + -0.27044 * if_mod5_eq_2 + -0.560389 * if_mod5_eq_2*v2 + -14.554502 * if_v2_ge_5 + 0.929219 * if_v2_ge_5*log2n + 0.582793 * if_v2_ge_5*v2 + 1.415786 * if_v2_ge_7*log2n + -2.997965 * if_v2_ge_7*v2
---
Model 6 :: if_mod3_eq_2 | if_mod5_eq_2 | if_v2_ge_3 | if_v2_ge_6 | if_v2_ge_7
steps_hat = 7.708345 * log2n + -6.247099 * v2 + -0.882263 * if_mod5_eq_2 + -0.419364 * if_v2_ge_3 + -0.03961 * if_v2_ge_3*v2 + 1.635021 * if_v2_ge_6*log2n + -3.268889 * if_v2_ge_6*v2 + 0.169443 * if_v2_ge_7*v2
---
Model 7 :: if_mod30_eq_2 | if_mod5_eq_2 | if_v2_ge_3 | if_v2_ge_7
steps_hat = 7.703856 * log2n + -6.228556 * v2 + 0.724355 * if_mod30_eq_2*v2 + -0.296094 * if_mod5_eq_2 + -0.538621 * if_mod5_eq_2*v2 + -0.845247 * if_v2_ge_3 + 0.11268 * if_v2_ge_3*v2 + 1.557811 * if_v2_ge_7*log2n + -3.053503 * if_v2_ge_7*v2
---
Model 8 :: if_mod12_eq_10 | if_mod30_eq_2 | if_mod5_eq_2 | if_v2_ge_6
steps_hat = 7.687986 * log2n + -6.268783 * v2 + 0.469738 * if_mod12_eq_10 + 0.469738 * if_mod12_eq_10*v2 + 0.753598 * if_mod30_eq_2*v2 + -0.292232 * if_mod5_eq_2 + -0.549661 * if_mod5_eq_2*v2 + 1.494063 * if_v2_ge_6*log2n + -2.917774 * if_v2_ge_6*v2
---
Model 9 :: if_mod12_eq_10 | if_mod3_eq_2 | if_v2_ge_3 | if_v2_ge_5 | if_v2_ge_7
steps_hat = 7.64785 * log2n + -6.041868 * v2 + 0.52161 * if_mod12_eq_10 + 0.52161 * if_mod12_eq_10*v2 + 0.187899 * if_mod3_eq_2*v2 + -0.676033 * if_v2_ge_3 + -0.061279 * if_v2_ge_3*v2 + 0.55694 * if_v2_ge_5*log2n + -1.332146 * if_v2_ge_5*v2 + 1.01444 * if_v2_ge_7*log2n + -1.814793 * if_v2_ge_7*v2
---
Model 10 :: if_mod12_eq_10 | if_mod30_eq_2 | if_mod5_eq_2 | if_v2_ge_4
steps_hat = 7.673447 * log2n + -6.153948 * v2 + 0.499598 * if_mod12_eq_10 + 0.499598 * if_mod12_eq_10*v2 + 0.735813 * if_mod30_eq_2*v2 + -0.249597 * if_mod5_eq_2 + -0.56119 * if_mod5_eq_2*v2 + -4.851832 * if_v2_ge_4 + 0.764521 * if_v2_ge_4*log2n + -1.126931 * if_v2_ge_4*v2
---
Model 11 :: if_mod12_eq_10 | if_mod30_eq_2 | if_mod3_eq_2 | if_v2_ge_6 | if_v2_ge_7
steps_hat = 7.68315 * log2n + -6.388306 * v2 + 0.475378 * if_mod12_eq_10 + 0.475378 * if_mod12_eq_10*v2 + 0.07995 * if_mod30_eq_2*v2 + 0.164225 * if_mod3_eq_2*v2 + 2.054321 * if_v2_ge_6*log2n + -4.144139 * if_v2_ge_6*v2 + -0.549968 * if_v2_ge_7*log2n + 1.25003 * if_v2_ge_7*v2
---
Model 12 :: if_mod12_eq_10 | if_mod3_eq_2 | if_v2_ge_2 | if_v2_ge_4 | if_v2_ge_7
steps_hat = -1.771082 * bias + 7.572159 * log2n + -3.422657 * v2 + 0.568107 * if_mod12_eq_10 + 0.568107 * if_mod12_eq_10*v2 + 0.191491 * if_mod3_eq_2*v2 + -1.377527 * if_v2_ge_2 + 0.390154 * if_v2_ge_2*log2n + -3.029102 * if_v2_ge_2*v2 + -0.104899 * if_v2_ge_4 + 1.401134 * if_v2_ge_7*log2n + -2.704279 * if_v2_ge_7*v2
---
Model 13 :: if_mod12_eq_10 | if_mod3_eq_2 | if_v2_ge_3 | if_v2_ge_5
steps_hat = 7.646789 * log2n + -6.0323 * v2 + 0.523424 * if_mod12_eq_10 + 0.523424 * if_mod12_eq_10*v2 + 0.184374 * if_mod3_eq_2*v2 + -0.37368 * if_v2_ge_3 + -0.154719 * if_v2_ge_3*v2 + 0.888944 * if_v2_ge_5*log2n + -2.062617 * if_v2_ge_5*v2
---
Model 14 :: if_mod12_eq_10 | if_mod3_eq_2 | if_mod5_eq_2 | if_v2_ge_3
steps_hat = -1.781203 * bias + 7.785744 * log2n + -5.88854 * v2 + 0.56608 * if_mod12_eq_10 + 0.56608 * if_mod12_eq_10*v2 + 0.183129 * if_mod3_eq_2*v2 + -0.87791 * if_mod5_eq_2 + 2.804294 * if_v2_ge_3 + -1.116873 * if_v2_ge_3*v2
---
Model 15 :: if_mod12_eq_10 | if_mod5_eq_2 | if_v2_ge_2 | if_v2_ge_4 | if_v2_ge_5
steps_hat = -1.780028 * bias + 7.741441 * log2n + -5.248057 * v2 + 0.520332 * if_mod12_eq_10 + 0.520332 * if_mod12_eq_10*v2 + -0.87451 * if_mod5_eq_2 + 2.091893 * if_v2_ge_2 + -1.376136 * if_v2_ge_2*v2 + 0.030005 * if_v2_ge_4*v2 + 0.757402 * if_v2_ge_5*log2n + -1.6016 * if_v2_ge_5*v2
---
Model 16 :: if_mod30_eq_2 | if_mod5_eq_2 | if_v2_ge_6
steps_hat = 7.716439 * log2n + -6.376529 * v2 + 0.715298 * if_mod30_eq_2*v2 + -0.276478 * if_mod5_eq_2 + -0.541814 * if_mod5_eq_2*v2 + 1.464132 * if_v2_ge_6*log2n + -2.80672 * if_v2_ge_6*v2
---
Model 17 :: if_mod30_eq_2 | if_mod5_eq_2 | if_v2_ge_5
steps_hat = 7.717164 * log2n + -6.38404 * v2 + -0.29368 * if_mod30_eq_2*log2n + 1.913521 * if_mod30_eq_2*v2 + 0.989592 * if_mod5_eq_2 + -0.964264 * if_mod5_eq_2*v2 + -6.683911 * if_v2_ge_5 + 1.256748 * if_v2_ge_5*log2n + -1.601293 * if_v2_ge_5*v2
---
Model 18 :: if_mod30_eq_2 | if_mod3_eq_2 | if_v2_ge_2 | if_v2_ge_3 | if_v2_ge_7
steps_hat = -3.00326 * bias + 7.766483 * log2n + -4.440083 * v2 + 0.092922 * if_mod30_eq_2*v2 + 1.02876 * if_mod3_eq_2 + -0.218338 * if_mod3_eq_2*v2 + 0.39165 * if_v2_ge_2 + -1.045173 * if_v2_ge_2*v2 + 0.600461 * if_v2_ge_3 + -0.627551 * if_v2_ge_3*v2 + 1.490842 * if_v2_ge_7*log2n + -2.943805 * if_v2_ge_7*v2
---
Model 19 :: if_mod5_eq_2 | if_v2_ge_3 | if_v2_ge_5 | if_v2_ge_6 | if_v2_ge_7
steps_hat = 7.707055 * log2n + -6.236735 * v2 + -0.879819 * if_mod5_eq_2 + -0.649281 * if_v2_ge_3 + 0.023553 * if_v2_ge_3*v2 + 0.417717 * if_v2_ge_5*log2n + -1.066494 * if_v2_ge_5*v2 + 1.084289 * if_v2_ge_6*log2n + -1.903916 * if_v2_ge_6*v2
---